# *Unofficial* Sumitomo (SHI) Cryogenics F-70 Helium Compressor Python Driver

Unofficial python driver for monitoring and controlling Sumitomo Cryogenics F-70 Helium Compressors through their serial (RS232) port. 

**NOTE:** this requires firmware version 1.6 or higher.
